Low Poly 3D Flashlight
This Low Poly Flashlight Pack contains 1 flash light with a 1 removable casing (at the back to insert batteries), and 1 battery - these assets have been textured, UV mapped, and unwrapped. The mesh and texture (after compression) are very small and can be used in a fps survival /adventure game. The assets can be easily imported into Unity or an open-source game engine like Superpowers.
3D Model Specifications

Geometry: Polygon
Textures: Yes
Materials: Yes
UV Mapped: Yes
Unwrapped UVs: Yes
Texture Format:  PNG
Texture Layer Organized: Yes
Texture Size: 1024x1024 
UV Information in Texture: Yes
Maps: Diffuse (Color)
Mobile Ready: Yes
Tried and Tested in: Unity 5+



Features
Free periodic updates
Only available on itch.io store
Very clean models/mesh
Ready for Unity projects

Please leave a review, If you like these assets, or have a specific art asset need.


License
Things you can do - 

This license grants you, the purchases, an ongoing, non-exclusive commercial, worldwide
grants you, the purchaser, an ongoing, non- exclusive, commercial, worldwide license to make use of 
the item (game asset) you have selected to make games, or interactive content. 


Things you can't do - 

You can�t re-distribute the Item as a game asset, as stock, in a tool or template, or with source files. You can�t do this with an Item either on its own or bundled with other items (such as an asset pack , or collection of item), and even if you modify the Item. You can�t re-distribute the Item as-is or with superficial modifications. These things are not allowed even if the re-distribution is for free.


Devil's Garage 


http://www.devilsgarage.com
http://twitter.com/devilsgarage 


